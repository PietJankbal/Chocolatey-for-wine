Media pack for the Vulkan examples at https://github.com/SaschaWillems/Vulkan

Put this in the same folder as the "bin" folder containing the binaries for your platform.

E.g. for windows:

C:\VULKAN_SAMPLES\
C:\VULKAN_SAMPLES\bin\triangle.exe
...
C:\VULKAN_SAMPLES\data\textures
C:\VULKAN_SAMPLES\data\models
...

Redistribution not allowed!